---
layout: post
title: jQuery解构
category: project
description: jQuery是一个伟大作品，他的完成充满智慧，我们来一点点拆解他，去理解作者的思想精华。
---
# [{{ page.title }}][1]
2012-01-16 By {{ site.author_info }}


[BeiYuu]:    http://beiyuu.com  "BeiYuu"
[1]:    {{ page.url}}  ({{ page.title }})
