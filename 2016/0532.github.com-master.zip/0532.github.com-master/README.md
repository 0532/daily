
[![Gitter](https://badges.gitter.im/Join Chat.svg)](https://gitter.im/0532/0532.github.io?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![](http://img.shields.io/badge/new-message-green.svg?style=flat-square)](https://github.com/0532/messages/issues/new)


Instead of sending me email use the [issue tracker](https://github.com/0532/messages/issues) to send me messages.and click here [:globe_with_meridians:](http://0532.github.io/) to visit. :tm:





